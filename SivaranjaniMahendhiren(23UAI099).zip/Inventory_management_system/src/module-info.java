/**
 * 
 */
/**
 * 
 */
module Inventory_management_system {
}